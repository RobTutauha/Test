# IT6033_practical_task_1_data_structures
Contains student files for the Task 1 in IT6033 Data Structures and Algorithms


  ListOfPatients.txt is required for Question 1
  
  TicketingSystem.java is required for Question 3
  
  Refer to the Practical Task 1 document in iQualify for the full list of instructions.
